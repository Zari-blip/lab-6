 #include<iostream>
 using namespace std;
 int main()
 {
 	int number;
 	int a=1;
 	int sum=0;
 	float average;
 	cout<<"\nenter number";
 	cin>>number;
 	do{
 		
 		a++;
 		sum=sum+number;
 		average=sum/a;
 		
	 }
	 while(a<=5);
	 cout<<"\nnumber is "<<number;
	 cout<<"\nsum is\n"<<sum;
	 cout<<"\naverage is\n"<<average;
	 return 0;
 }

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
