

#include<iostream>
using namespace std;
int main()
{
	int password;
	
	int a;
	while(a<=5)
	{	cout<<"\nenter password\n"<<password;
	cin>>password;
	if(password==1234)
	{
		cout<<"\npassword is correct\n"<<password;
	}
	else
	{
		cout<<"\npassword is incorrect\n"<<password;
	}

	}
	return 0;
}






